# AWS CodePipeline Manual Setup Guide

## Complete Step-by-Step Guide for Infrastructure CI/CD

This guide walks you through manually creating a CodePipeline that deploys CloudFormation infrastructure across multiple environments (DEV → QA → UAT → PROD).

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Architecture Overview](#2-architecture-overview)
3. [Step 1: Create S3 Artifact Bucket](#3-step-1-create-s3-artifact-bucket)
4. [Step 2: Create CodeCommit Repository](#4-step-2-create-codecommit-repository)
5. [Step 3: Create IAM Roles](#5-step-3-create-iam-roles)
6. [Step 4: Create CodeBuild Project](#6-step-4-create-codebuild-project)
7. [Step 5: Create CodePipeline](#7-step-5-create-codepipeline)
8. [Step 6: Test the Pipeline](#8-step-6-test-the-pipeline)
9. [Troubleshooting](#9-troubleshooting)

---

## 1. Prerequisites

Before starting, ensure you have:

- AWS Account with Administrator access
- AWS CLI installed and configured
- Git installed locally
- Basic understanding of CloudFormation

**Estimated Time:** 45-60 minutes

---

## 2. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           CodePipeline                                   │
├─────────────┬─────────────┬─────────────┬─────────────┬─────────────────┤
│   SOURCE    │    BUILD    │     DEV     │     QA      │     PROD        │
│             │             │             │             │                 │
│ CodeCommit  │  CodeBuild  │  CFN Deploy │  CFN Deploy │  Manual Approve │
│    main     │  - Lint     │  (Auto)     │  (Auto)     │  + CFN Deploy   │
│    branch   │  - Package  │             │             │  (Change Set)   │
└─────────────┴─────────────┴─────────────┴─────────────┴─────────────────┘
```

**What Gets Deployed:**
- VPC with public/private subnets, NAT Gateway
- Application Load Balancer
- ECS Fargate Cluster and Service
- Lambda Function
- S3 Buckets
- IAM Roles and Security Groups

---

## 3. Step 1: Create S3 Artifact Bucket

This bucket stores pipeline artifacts and CloudFormation templates.

### Console Steps:

1. **Open S3 Console:** `https://console.aws.amazon.com/s3`

2. **Create Bucket:**
   - Click **Create bucket**
   - Bucket name: `myapp-pipeline-artifacts-{ACCOUNT_ID}`
   - Region: Select your region (e.g., `us-east-1`)
   - **Block Public Access:** Keep all options CHECKED ✓
   - **Bucket Versioning:** Enable
   - Click **Create bucket**

3. **Create Folders:**
   - Open the bucket
   - Click **Create folder** → Name: `templates` → Create
   - Click **Create folder** → Name: `artifacts` → Create

### Why This Matters:
- Pipeline artifacts (source code, build outputs) stored here
- Nested CloudFormation templates uploaded here
- Versioning allows rollback if needed

---

## 4. Step 2: Create CodeCommit Repository

### Console Steps:

1. **Open CodeCommit Console:** `https://console.aws.amazon.com/codecommit`

2. **Create Repository:**
   - Click **Create repository**
   - Repository name: `myapp-infrastructure`
   - Description: `Infrastructure as Code for MyApp`
   - Click **Create**

3. **Clone and Push Code:**
   ```bash
   # Clone empty repository
   git clone https://git-codecommit.{REGION}.amazonaws.com/v1/repos/myapp-infrastructure
   
   # Copy your CloudFormation templates into the repo
   # (templates/, buildspecs/, etc.)
   
   # Push to CodeCommit
   git add .
   git commit -m "Initial infrastructure templates"
   git push origin main
   ```

### Repository Structure:
```
myapp-infrastructure/
├── templates/
│   ├── master-stack.yaml          # Main orchestration template
│   ├── nested/
│   │   ├── vpc.yaml               # VPC, subnets, NAT
│   │   ├── security.yaml          # IAM roles, security groups
│   │   ├── s3.yaml                # S3 buckets
│   │   ├── alb.yaml               # Application Load Balancer
│   │   ├── lambda.yaml            # Lambda functions
│   │   └── ecs.yaml               # ECS Fargate
│   └── parameters/
│       ├── dev.json
│       ├── qa.json
│       └── prod.json
└── buildspecs/
    └── buildspec-validate.yaml     # Build specification
```

---

## 5. Step 3: Create IAM Roles

You need THREE roles for the pipeline to work.

### Role 1: CodePipeline Service Role

1. **Open IAM Console:** `https://console.aws.amazon.com/iam`

2. **Create Role:**
   - Click **Roles** → **Create role**
   - Trusted entity: **AWS Service**
   - Use case: **CodePipeline**
   - Click **Next**

3. **Attach Policies:**
   - Search and select: `AWSCodePipelineFullAccess`
   - Click **Next**

4. **Name and Create:**
   - Role name: `myapp-codepipeline-role`
   - Click **Create role**

5. **Add Inline Policy:**
   - Open the role you just created
   - Click **Add permissions** → **Create inline policy**
   - Select **JSON** tab and paste:

   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Action": [
           "codecommit:GetBranch",
           "codecommit:GetCommit",
           "codecommit:GetUploadArchiveStatus",
           "codecommit:UploadArchive",
           "codecommit:CancelUploadArchive"
         ],
         "Resource": "arn:aws:codecommit:*:*:myapp-infrastructure"
       },
       {
         "Effect": "Allow",
         "Action": [
           "codebuild:StartBuild",
           "codebuild:BatchGetBuilds"
         ],
         "Resource": "*"
       },
       {
         "Effect": "Allow",
         "Action": [
           "cloudformation:CreateStack",
           "cloudformation:UpdateStack",
           "cloudformation:DeleteStack",
           "cloudformation:DescribeStacks",
           "cloudformation:CreateChangeSet",
           "cloudformation:ExecuteChangeSet",
           "cloudformation:DeleteChangeSet",
           "cloudformation:DescribeChangeSet"
         ],
         "Resource": "*"
       },
       {
         "Effect": "Allow",
         "Action": [
           "s3:GetObject",
           "s3:PutObject",
           "s3:GetBucketVersioning"
         ],
         "Resource": [
           "arn:aws:s3:::myapp-pipeline-artifacts-*",
           "arn:aws:s3:::myapp-pipeline-artifacts-*/*"
         ]
       },
       {
         "Effect": "Allow",
         "Action": "iam:PassRole",
         "Resource": "*",
         "Condition": {
           "StringEquals": {
             "iam:PassedToService": "cloudformation.amazonaws.com"
           }
         }
       }
     ]
   }
   ```
   - Policy name: `CodePipelineCustomPolicy`
   - Click **Create policy**

---

### Role 2: CodeBuild Service Role

1. **Create Role:**
   - Click **Roles** → **Create role**
   - Trusted entity: **AWS Service**
   - Use case: **CodeBuild**
   - Click **Next**

2. **Attach Policies:**
   - Search and select: `AWSCodeBuildAdminAccess`
   - Click **Next**

3. **Name and Create:**
   - Role name: `myapp-codebuild-role`
   - Click **Create role**

4. **Add Inline Policy:**
   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Action": [
           "logs:CreateLogGroup",
           "logs:CreateLogStream",
           "logs:PutLogEvents"
         ],
         "Resource": "arn:aws:logs:*:*:log-group:/aws/codebuild/*"
       },
       {
         "Effect": "Allow",
         "Action": [
           "s3:GetObject",
           "s3:PutObject",
           "s3:ListBucket"
         ],
         "Resource": [
           "arn:aws:s3:::myapp-pipeline-artifacts-*",
           "arn:aws:s3:::myapp-pipeline-artifacts-*/*"
         ]
       },
       {
         "Effect": "Allow",
         "Action": [
           "cloudformation:ValidateTemplate"
         ],
         "Resource": "*"
       }
     ]
   }
   ```
   - Policy name: `CodeBuildCustomPolicy`

---

### Role 3: CloudFormation Service Role

1. **Create Role:**
   - Click **Roles** → **Create role**
   - Trusted entity: **AWS Service**
   - Use case: **CloudFormation**
   - Click **Next**

2. **Attach Policies:**
   - `AmazonVPCFullAccess`
   - `AmazonEC2FullAccess`
   - `AmazonECS_FullAccess`
   - `AmazonS3FullAccess`
   - `AWSLambda_FullAccess`
   - `ElasticLoadBalancingFullAccess`
   - `IAMFullAccess`
   - `CloudWatchLogsFullAccess`

3. **Name and Create:**
   - Role name: `myapp-cloudformation-role`
   - Click **Create role**

---

## 6. Step 4: Create CodeBuild Project

1. **Open CodeBuild Console:** `https://console.aws.amazon.com/codebuild`

2. **Create Build Project:**
   - Click **Create build project**

3. **Project Configuration:**
   - Project name: `myapp-infra-build`
   - Description: `Validate and package CloudFormation templates`

4. **Source:**
   - Source provider: **AWS CodeCommit**
   - Repository: `myapp-infrastructure`
   - Branch: `main`

5. **Environment:**
   - Environment image: **Managed image**
   - Operating system: **Ubuntu**
   - Runtime: **Standard**
   - Image: `aws/codebuild/standard:7.0`
   - Service role: **Existing service role**
   - Role ARN: Select `myapp-codebuild-role`

6. **Buildspec:**
   - Build specifications: **Use a buildspec file**
   - Buildspec name: `buildspecs/buildspec-validate.yaml`

7. **Environment Variables:**
   - Click **Add environment variable**
   - Name: `TEMPLATES_BUCKET` | Value: `myapp-pipeline-artifacts-{ACCOUNT_ID}`
   - Name: `ENVIRONMENT` | Value: `dev`

8. **Artifacts:**
   - Type: **Amazon S3**
   - Bucket name: `myapp-pipeline-artifacts-{ACCOUNT_ID}`
   - Name: `build-output`

9. **Logs:**
   - CloudWatch logs: ✓ Enable
   - Group name: `/aws/codebuild/myapp-infra-build`

10. Click **Create build project**

---

## 7. Step 5: Create CodePipeline

1. **Open CodePipeline Console:** `https://console.aws.amazon.com/codepipeline`

2. **Create Pipeline:**
   - Click **Create pipeline**

3. **Pipeline Settings:**
   - Pipeline name: `myapp-infrastructure-pipeline`
   - Pipeline type: **V2**
   - Service role: **Existing service role**
   - Role ARN: Select `myapp-codepipeline-role`
   - Artifact store: **Custom location**
   - Bucket: `myapp-pipeline-artifacts-{ACCOUNT_ID}`
   - Click **Next**

4. **Add Source Stage:**
   - Source provider: **AWS CodeCommit**
   - Repository name: `myapp-infrastructure`
   - Branch name: `main`
   - Change detection: **Amazon CloudWatch Events**
   - Output artifact: `SourceOutput`
   - Click **Next**

5. **Add Build Stage:**
   - Build provider: **AWS CodeBuild**
   - Project name: `myapp-infra-build`
   - Input artifacts: `SourceOutput`
   - Output artifacts: `BuildOutput`
   - Click **Next**

6. **Add Deploy Stage (Initial - DEV):**
   - Deploy provider: **AWS CloudFormation**
   - Action mode: **Create or update a stack**
   - Stack name: `myapp-dev-stack`
   - Template: `BuildOutput::packaged-master.yaml`
   - Template configuration: `BuildOutput::templates/parameters/dev.json`
   - Capabilities: **CAPABILITY_NAMED_IAM**
   - Role name: `myapp-cloudformation-role`
   - Input artifacts: `BuildOutput`
   - Click **Next**

7. **Review and Create:**
   - Review all settings
   - Click **Create pipeline**

---

### Adding Additional Stages (QA, UAT, PROD)

After pipeline creation, edit it to add more stages:

1. **Edit Pipeline:**
   - Open your pipeline
   - Click **Edit**

2. **Add QA Stage:**
   - Click **Add stage** after DEV
   - Stage name: `Deploy-QA`
   - Add action:
     - Action name: `Deploy-QA-Stack`
     - Provider: **AWS CloudFormation**
     - Action mode: **Create or update a stack**
     - Stack name: `myapp-qa-stack`
     - Template: `BuildOutput::packaged-master.yaml`
     - Configuration file: `BuildOutput::templates/parameters/qa.json`
     - Capabilities: **CAPABILITY_NAMED_IAM**
     - Role name: `myapp-cloudformation-role`

3. **Add PROD Stage with Approval:**
   - Click **Add stage**
   - Stage name: `Deploy-PROD`
   
   **First Action - Manual Approval:**
   - Action name: `Approval`
   - Provider: **Manual approval**
   - Comments: `Please review change set before production deployment`
   
   **Second Action - Create Change Set:**
   - Action name: `Create-ChangeSet`
   - Provider: **AWS CloudFormation**
   - Action mode: **Create or replace a change set**
   - Stack name: `myapp-prod-stack`
   - Change set name: `prod-changeset`
   - Template: `BuildOutput::packaged-master.yaml`
   - Configuration file: `BuildOutput::templates/parameters/prod.json`
   
   **Third Action - Execute Change Set:**
   - Action name: `Execute-ChangeSet`
   - Provider: **AWS CloudFormation**
   - Action mode: **Execute a change set**
   - Stack name: `myapp-prod-stack`
   - Change set name: `prod-changeset`

4. Click **Save**

---

## 8. Step 6: Test the Pipeline

1. **Trigger Pipeline:**
   - Make a small change to any template
   - Commit and push to CodeCommit
   - Pipeline should automatically trigger

2. **Monitor Execution:**
   - Watch each stage turn green
   - Click on stages to see details
   - Check CodeBuild logs for validation output

3. **Verify Deployment:**
   - Open CloudFormation console
   - Check `myapp-dev-stack` was created
   - Review stack outputs for ALB URL

4. **Test Application:**
   ```bash
   # Get ALB DNS name from stack outputs
   curl http://{ALB-DNS-NAME}/health
   ```

---

## 9. Troubleshooting

### Common Issues:

**Pipeline Fails at Source Stage:**
- Check CodeCommit repository permissions
- Verify branch name is correct
- Ensure IAM role has codecommit:* permissions

**Build Stage Fails:**
- Check CloudWatch logs: `/aws/codebuild/myapp-infra-build`
- Verify buildspec path is correct
- Check template syntax with `cfn-lint`

**Deploy Stage Fails:**
- Review CloudFormation events in console
- Check IAM role has required permissions
- Look for resource limit issues

**Stack Stuck in ROLLBACK:**
```bash
# Delete and recreate
aws cloudformation delete-stack --stack-name myapp-dev-stack
# Wait for deletion, then re-run pipeline
```

### Useful Commands:

```bash
# Validate template locally
aws cloudformation validate-template \
  --template-body file://templates/master-stack.yaml

# List stack events
aws cloudformation describe-stack-events \
  --stack-name myapp-dev-stack

# Get stack outputs
aws cloudformation describe-stacks \
  --stack-name myapp-dev-stack \
  --query 'Stacks[0].Outputs'
```

---

## Next Steps

After successful pipeline setup:

1. **Add SNS Notifications:** Configure pipeline notifications for failures
2. **Enable WAF:** Add WAF to ALB for production
3. **Set Up Monitoring:** Create CloudWatch dashboards
4. **Implement Secrets:** Use Secrets Manager for sensitive data
5. **Add Testing Stage:** Include integration tests between stages

---

## Quick Reference

| Resource | Name |
|----------|------|
| S3 Bucket | `myapp-pipeline-artifacts-{ACCOUNT_ID}` |
| CodeCommit Repo | `myapp-infrastructure` |
| CodeBuild Project | `myapp-infra-build` |
| Pipeline | `myapp-infrastructure-pipeline` |
| DEV Stack | `myapp-dev-stack` |
| QA Stack | `myapp-qa-stack` |
| PROD Stack | `myapp-prod-stack` |
| CodePipeline Role | `myapp-codepipeline-role` |
| CodeBuild Role | `myapp-codebuild-role` |
| CloudFormation Role | `myapp-cloudformation-role` |
