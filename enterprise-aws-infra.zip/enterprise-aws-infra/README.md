# Enterprise AWS Infrastructure

A comprehensive, production-ready AWS CloudFormation infrastructure solution supporting VPC, IAM, EC2, ALB, Lambda, S3, ECS Fargate, ECR with CI/CD pipelines for multi-environment deployments.

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           AWS Account                                    │
├─────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                        VPC (Multi-AZ)                            │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │   │
│  │  │ Public      │  │ Public      │  │ Public      │              │   │
│  │  │ Subnet 1    │  │ Subnet 2    │  │ Subnet 3    │              │   │
│  │  │ (ALB, NAT)  │  │ (ALB, NAT)  │  │ (ALB, NAT)  │              │   │
│  │  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘              │   │
│  │         │                │                │                      │   │
│  │  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐              │   │
│  │  │ Private     │  │ Private     │  │ Private     │              │   │
│  │  │ Subnet 1    │  │ Subnet 2    │  │ Subnet 3    │              │   │
│  │  │ (ECS/Lambda)│  │ (ECS/Lambda)│  │ (ECS/Lambda)│              │   │
│  │  └──────┬──────┘  └──────┬──────┘  └──────┴──────┘              │   │
│  │         │                │                │                      │   │
│  │  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐              │   │
│  │  │ Database    │  │ Database    │  │ Database    │              │   │
│  │  │ Subnet 1    │  │ Subnet 2    │  │ Subnet 3    │              │   │
│  │  │ (RDS/Cache) │  │ (RDS/Cache) │  │ (RDS/Cache) │              │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
```

## 📁 Project Structure

```
enterprise-aws-infra/
├── templates/
│   ├── network/
│   │   └── vpc.yaml              # VPC, subnets, NAT, endpoints
│   ├── security/
│   │   ├── iam.yaml              # IAM roles for all services
│   │   └── security-groups.yaml  # Security groups
│   ├── compute/
│   │   ├── alb.yaml              # Application Load Balancer
│   │   ├── ecs-fargate.yaml      # ECS cluster and services
│   │   └── lambda.yaml           # Lambda functions
│   ├── storage/
│   │   ├── s3.yaml               # S3 buckets
│   │   └── ecr.yaml              # ECR repositories
│   └── monitoring/
│       └── monitoring.yaml       # CloudWatch, alarms, dashboards
├── pipeline/
│   └── codepipeline.yaml         # CI/CD pipeline
├── envs/
│   ├── dev.json                  # Development configuration
│   ├── qa.json                   # QA configuration
│   ├── uat.json                  # UAT configuration
│   └── prod.json                 # Production configuration
├── scripts/
│   └── deploy.sh                 # Deployment script
└── docs/
    └── README.md                 # This file
```

## 🚀 Quick Start

### Prerequisites

- AWS CLI v2 configured with appropriate permissions
- Bash 4.0+
- Python 3.9+ (for template validation)

### Deploy to Development

```bash
# Validate templates
./scripts/deploy.sh validate

# Deploy all stacks to dev
./scripts/deploy.sh deploy dev

# Check status
./scripts/deploy.sh status dev
```

### Deploy to Production

```bash
# Deploy with approval workflow
./scripts/deploy.sh deploy prod --wait

# Or deploy individual stacks
./scripts/deploy.sh deploy-stack prod --stack vpc
./scripts/deploy.sh deploy-stack prod --stack iam
./scripts/deploy.sh deploy-stack prod --stack ecs
```

## 🌍 Environments

| Environment | VPC CIDR | AZs | Auto-Scaling | WAF | Notes |
|-------------|----------|-----|--------------|-----|-------|
| dev | 10.0.0.0/16 | 2 | 1-3 | No | Development, SSH enabled |
| qa | 10.1.0.0/16 | 2 | 2-5 | Yes | QA testing |
| uat | 10.2.0.0/16 | 2 | 2-6 | Yes | User acceptance testing |
| prod | 10.3.0.0/16 | 3 | 3-20 | Yes | Production, HA NAT |

## 📦 Stack Components

### Network (vpc.yaml)
- VPC with DNS support
- 3-tier subnet architecture (public, private, database)
- NAT Gateways (HA for production)
- VPC Flow Logs
- VPC Endpoints (S3, DynamoDB, ECR, Secrets Manager)

### Security (iam.yaml, security-groups.yaml)
- Least-privilege IAM roles for:
  - ECS Task Execution
  - ECS Task
  - Lambda
  - EC2
  - CodePipeline/CodeBuild
  - CloudFormation
- Security groups for all tiers
- Permission boundaries support

### Compute (alb.yaml, ecs-fargate.yaml, lambda.yaml)
- Application Load Balancer with WAF
- ECS Fargate with auto-scaling
- Lambda with VPC support
- Service discovery via Cloud Map
- Container Insights

### Storage (s3.yaml, ecr.yaml)
- S3 buckets with:
  - KMS encryption
  - Lifecycle policies
  - Versioning
  - Access logging
- ECR with:
  - Image scanning
  - Lifecycle policies
  - Cross-account access

### Monitoring (monitoring.yaml)
- CloudWatch Dashboards
- Alarms for CPU, memory, errors
- SNS notifications
- X-Ray tracing
- EventBridge rules

## 🔄 CI/CD Pipeline

The pipeline (codepipeline.yaml) provides:

1. **Source** - CodeCommit trigger on main branch
2. **Validate** - CloudFormation linting and security scan
3. **Build** - Docker build and ECR push
4. **Deploy Dev** - Automatic deployment
5. **Deploy QA** - Automatic deployment
6. **Deploy UAT** - Automatic deployment
7. **Approval** - Manual gate for production
8. **Deploy Prod** - Production deployment

### Pipeline Features
- Change set previews
- Rollback on failure
- SNS notifications
- Blue/Green deployment support

## 🔧 Customization

### Adding a New Service

1. Create a new ECS service in `ecs-fargate.yaml`
2. Add target group in `alb.yaml`
3. Update security groups as needed
4. Add monitoring in `monitoring.yaml`

### Environment-Specific Settings

Edit the appropriate JSON file in `envs/`:

```json
{
  "Parameters": {
    "ContainerCpu": "1024",
    "ContainerMemory": "2048",
    "DesiredCount": "3"
  }
}
```

## 🛡️ Security Features

- KMS encryption for all data at rest
- VPC endpoints for private AWS API access
- WAF with AWS managed rules
- Security groups with least-privilege
- IAM permission boundaries
- VPC Flow Logs
- CloudTrail integration ready
- Secrets Manager integration

## 📊 Monitoring & Observability

- **CloudWatch Dashboards** - Real-time metrics
- **CloudWatch Alarms** - CPU, memory, errors, latency
- **Container Insights** - ECS-specific metrics
- **X-Ray** - Distributed tracing
- **VPC Flow Logs** - Network monitoring

## 💰 Cost Optimization

- Fargate Spot for non-prod workloads
- S3 lifecycle policies
- NAT Gateway consolidation in non-prod
- Right-sized container definitions per environment

## 🔄 Maintenance Commands

```bash
# List all stacks
./scripts/deploy.sh list dev

# Show stack status
./scripts/deploy.sh status prod

# Delete environment (use with caution)
./scripts/deploy.sh delete dev --force

# Delete specific stack
./scripts/deploy.sh delete-stack qa --stack ecs
```

## 📝 Best Practices Implemented

1. **Infrastructure as Code** - All resources defined in CloudFormation
2. **Multi-Environment Support** - Consistent deployments across environments
3. **Security First** - Encryption, least-privilege, network isolation
4. **High Availability** - Multi-AZ, auto-scaling, health checks
5. **Observability** - Comprehensive logging, monitoring, tracing
6. **Cost Optimization** - Right-sizing, lifecycle policies, spot instances
7. **Disaster Recovery** - S3 versioning, backup buckets
8. **Compliance Ready** - Audit logging, encryption, retention policies

## 📚 Additional Resources

- [AWS CloudFormation Documentation](https://docs.aws.amazon.com/cloudformation/)
- [AWS ECS Best Practices](https://docs.aws.amazon.com/AmazonECS/latest/bestpracticesguide/)
- [AWS Well-Architected Framework](https://aws.amazon.com/architecture/well-architected/)

## 🆘 Troubleshooting

### Stack Creation Fails
1. Check CloudFormation events in AWS Console
2. Verify IAM permissions
3. Check resource limits in your account

### ECS Tasks Not Starting
1. Check ECS task logs in CloudWatch
2. Verify container image exists in ECR
3. Check security group rules
4. Verify IAM role permissions

### ALB Health Checks Failing
1. Verify health check path returns 200
2. Check security group allows ALB to ECS communication
3. Verify container is listening on correct port

## 📄 License

MIT License - See LICENSE file for details
