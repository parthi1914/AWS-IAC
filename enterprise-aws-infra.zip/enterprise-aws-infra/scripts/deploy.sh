#!/bin/bash
# =============================================================================
# Enterprise AWS Infrastructure Deployment Script
# Version: 2.0.0
# =============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="${PROJECT_NAME:-enterprise}"
AWS_REGION="${AWS_REGION:-us-east-1}"
TEMPLATES_DIR="$(dirname "$0")/../templates"
ENVS_DIR="$(dirname "$0")/../envs"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

usage() {
    cat << EOF
Usage: $0 <command> <environment> [options]

Commands:
    deploy          Deploy all stacks for an environment
    deploy-stack    Deploy a specific stack
    delete          Delete all stacks for an environment
    delete-stack    Delete a specific stack
    validate        Validate all templates
    list            List all stacks for an environment
    status          Show stack status

Environments:
    dev, qa, uat, prod

Options:
    --stack <name>  Stack name (for deploy-stack/delete-stack)
    --dry-run       Show what would be deployed without deploying
    --force         Skip confirmation prompts
    --wait          Wait for stack operations to complete

Examples:
    $0 deploy dev
    $0 deploy-stack prod --stack vpc
    $0 delete qa --force
    $0 validate

Stacks (deployment order):
    1. vpc           - VPC and networking
    2. security      - IAM roles and security groups
    3. storage       - S3 and ECR
    4. alb           - Application Load Balancer
    5. ecs           - ECS Cluster and Services
    6. lambda        - Lambda functions
    7. monitoring    - CloudWatch and alerts

EOF
    exit 1
}

validate_environment() {
    local env=$1
    if [[ ! "$env" =~ ^(dev|qa|uat|prod)$ ]]; then
        log_error "Invalid environment: $env"
        log_info "Valid environments: dev, qa, uat, prod"
        exit 1
    fi
}

validate_templates() {
    log_info "Validating CloudFormation templates..."
    
    local templates=(
        "network/vpc.yaml"
        "security/iam.yaml"
        "security/security-groups.yaml"
        "storage/s3.yaml"
        "storage/ecr.yaml"
        "compute/alb.yaml"
        "compute/ecs-fargate.yaml"
        "compute/lambda.yaml"
        "monitoring/monitoring.yaml"
    )
    
    for template in "${templates[@]}"; do
        local path="${TEMPLATES_DIR}/${template}"
        if [[ -f "$path" ]]; then
            log_info "Validating $template..."
            aws cloudformation validate-template \
                --template-body "file://${path}" \
                --region "$AWS_REGION" > /dev/null
            log_success "Valid: $template"
        else
            log_warning "Template not found: $template"
        fi
    done
    
    log_success "All templates validated successfully!"
}

deploy_stack() {
    local stack_name=$1
    local template_path=$2
    local env=$3
    local params_file="${ENVS_DIR}/${env}.json"
    
    local full_stack_name="${PROJECT_NAME}-${env}-${stack_name}"
    
    log_info "Deploying stack: $full_stack_name"
    
    # Check if stack exists
    if aws cloudformation describe-stacks --stack-name "$full_stack_name" --region "$AWS_REGION" 2>/dev/null; then
        log_info "Stack exists, updating..."
        local action="update"
    else
        log_info "Creating new stack..."
        local action="create"
    fi
    
    # Create change set
    local changeset_name="${full_stack_name}-$(date +%Y%m%d%H%M%S)"
    
    aws cloudformation create-change-set \
        --stack-name "$full_stack_name" \
        --change-set-name "$changeset_name" \
        --template-body "file://${template_path}" \
        --parameters "file://${params_file}" \
        --capabilities CAPABILITY_NAMED_IAM CAPABILITY_AUTO_EXPAND \
        --region "$AWS_REGION" \
        --tags "Key=Environment,Value=${env}" "Key=Project,Value=${PROJECT_NAME}"
    
    log_info "Waiting for change set to be created..."
    aws cloudformation wait change-set-create-complete \
        --stack-name "$full_stack_name" \
        --change-set-name "$changeset_name" \
        --region "$AWS_REGION" 2>/dev/null || true
    
    # Check if change set has changes
    local status=$(aws cloudformation describe-change-set \
        --stack-name "$full_stack_name" \
        --change-set-name "$changeset_name" \
        --query 'Status' \
        --output text \
        --region "$AWS_REGION")
    
    if [[ "$status" == "FAILED" ]]; then
        local reason=$(aws cloudformation describe-change-set \
            --stack-name "$full_stack_name" \
            --change-set-name "$changeset_name" \
            --query 'StatusReason' \
            --output text \
            --region "$AWS_REGION")
        
        if [[ "$reason" == *"didn't contain changes"* ]]; then
            log_info "No changes to deploy for $full_stack_name"
            aws cloudformation delete-change-set \
                --stack-name "$full_stack_name" \
                --change-set-name "$changeset_name" \
                --region "$AWS_REGION"
            return 0
        else
            log_error "Change set failed: $reason"
            return 1
        fi
    fi
    
    # Execute change set
    log_info "Executing change set..."
    aws cloudformation execute-change-set \
        --stack-name "$full_stack_name" \
        --change-set-name "$changeset_name" \
        --region "$AWS_REGION"
    
    if [[ "$WAIT" == "true" ]]; then
        log_info "Waiting for stack ${action} to complete..."
        aws cloudformation wait "stack-${action}-complete" \
            --stack-name "$full_stack_name" \
            --region "$AWS_REGION"
        log_success "Stack $full_stack_name ${action}d successfully!"
    else
        log_success "Stack deployment initiated: $full_stack_name"
    fi
}

deploy_all() {
    local env=$1
    
    log_info "Deploying all stacks for environment: $env"
    
    # Deployment order
    deploy_stack "vpc" "${TEMPLATES_DIR}/network/vpc.yaml" "$env"
    deploy_stack "iam" "${TEMPLATES_DIR}/security/iam.yaml" "$env"
    deploy_stack "security-groups" "${TEMPLATES_DIR}/security/security-groups.yaml" "$env"
    deploy_stack "s3" "${TEMPLATES_DIR}/storage/s3.yaml" "$env"
    deploy_stack "ecr" "${TEMPLATES_DIR}/storage/ecr.yaml" "$env"
    deploy_stack "alb" "${TEMPLATES_DIR}/compute/alb.yaml" "$env"
    deploy_stack "ecs" "${TEMPLATES_DIR}/compute/ecs-fargate.yaml" "$env"
    deploy_stack "lambda" "${TEMPLATES_DIR}/compute/lambda.yaml" "$env"
    deploy_stack "monitoring" "${TEMPLATES_DIR}/monitoring/monitoring.yaml" "$env"
    
    log_success "All stacks deployed for environment: $env"
}

delete_stack() {
    local stack_name=$1
    local env=$2
    
    local full_stack_name="${PROJECT_NAME}-${env}-${stack_name}"
    
    if [[ "$FORCE" != "true" ]]; then
        read -p "Are you sure you want to delete stack $full_stack_name? (y/N) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log_info "Deletion cancelled"
            return 0
        fi
    fi
    
    log_info "Deleting stack: $full_stack_name"
    
    aws cloudformation delete-stack \
        --stack-name "$full_stack_name" \
        --region "$AWS_REGION"
    
    if [[ "$WAIT" == "true" ]]; then
        log_info "Waiting for stack deletion to complete..."
        aws cloudformation wait stack-delete-complete \
            --stack-name "$full_stack_name" \
            --region "$AWS_REGION"
        log_success "Stack $full_stack_name deleted successfully!"
    else
        log_success "Stack deletion initiated: $full_stack_name"
    fi
}

delete_all() {
    local env=$1
    
    if [[ "$env" == "prod" && "$FORCE" != "true" ]]; then
        log_error "Cannot delete production stacks without --force flag"
        exit 1
    fi
    
    log_warning "Deleting ALL stacks for environment: $env"
    
    # Reverse deployment order for deletion
    delete_stack "monitoring" "$env"
    delete_stack "lambda" "$env"
    delete_stack "ecs" "$env"
    delete_stack "alb" "$env"
    delete_stack "ecr" "$env"
    delete_stack "s3" "$env"
    delete_stack "security-groups" "$env"
    delete_stack "iam" "$env"
    delete_stack "vpc" "$env"
    
    log_success "All stacks deleted for environment: $env"
}

list_stacks() {
    local env=$1
    
    log_info "Listing stacks for environment: $env"
    
    aws cloudformation list-stacks \
        --stack-status-filter CREATE_COMPLETE UPDATE_COMPLETE \
        --query "StackSummaries[?contains(StackName, '${PROJECT_NAME}-${env}')].{Name:StackName,Status:StackStatus,Updated:LastUpdatedTime}" \
        --output table \
        --region "$AWS_REGION"
}

show_status() {
    local env=$1
    
    log_info "Stack status for environment: $env"
    
    local stacks=(vpc iam security-groups s3 ecr alb ecs lambda monitoring)
    
    for stack in "${stacks[@]}"; do
        local full_name="${PROJECT_NAME}-${env}-${stack}"
        local status=$(aws cloudformation describe-stacks \
            --stack-name "$full_name" \
            --query 'Stacks[0].StackStatus' \
            --output text \
            --region "$AWS_REGION" 2>/dev/null || echo "NOT_FOUND")
        
        case "$status" in
            *COMPLETE)
                echo -e "${GREEN}✓${NC} $full_name: $status"
                ;;
            *IN_PROGRESS)
                echo -e "${YELLOW}⋯${NC} $full_name: $status"
                ;;
            *FAILED|*ROLLBACK*)
                echo -e "${RED}✗${NC} $full_name: $status"
                ;;
            NOT_FOUND)
                echo -e "${BLUE}○${NC} $full_name: Not deployed"
                ;;
            *)
                echo -e "${YELLOW}?${NC} $full_name: $status"
                ;;
        esac
    done
}

# Parse arguments
COMMAND=""
ENVIRONMENT=""
STACK=""
DRY_RUN="false"
FORCE="false"
WAIT="true"

while [[ $# -gt 0 ]]; do
    case $1 in
        deploy|deploy-stack|delete|delete-stack|validate|list|status)
            COMMAND=$1
            shift
            ;;
        dev|qa|uat|prod)
            ENVIRONMENT=$1
            shift
            ;;
        --stack)
            STACK=$2
            shift 2
            ;;
        --dry-run)
            DRY_RUN="true"
            shift
            ;;
        --force)
            FORCE="true"
            shift
            ;;
        --wait)
            WAIT="true"
            shift
            ;;
        --no-wait)
            WAIT="false"
            shift
            ;;
        -h|--help)
            usage
            ;;
        *)
            log_error "Unknown option: $1"
            usage
            ;;
    esac
done

# Validate command
if [[ -z "$COMMAND" ]]; then
    log_error "Command required"
    usage
fi

# Execute command
case $COMMAND in
    validate)
        validate_templates
        ;;
    deploy)
        validate_environment "$ENVIRONMENT"
        deploy_all "$ENVIRONMENT"
        ;;
    deploy-stack)
        validate_environment "$ENVIRONMENT"
        if [[ -z "$STACK" ]]; then
            log_error "--stack parameter required"
            usage
        fi
        # Map stack name to template path
        case $STACK in
            vpc) template="network/vpc.yaml" ;;
            iam) template="security/iam.yaml" ;;
            security-groups) template="security/security-groups.yaml" ;;
            s3) template="storage/s3.yaml" ;;
            ecr) template="storage/ecr.yaml" ;;
            alb) template="compute/alb.yaml" ;;
            ecs) template="compute/ecs-fargate.yaml" ;;
            lambda) template="compute/lambda.yaml" ;;
            monitoring) template="monitoring/monitoring.yaml" ;;
            *) log_error "Unknown stack: $STACK"; exit 1 ;;
        esac
        deploy_stack "$STACK" "${TEMPLATES_DIR}/${template}" "$ENVIRONMENT"
        ;;
    delete)
        validate_environment "$ENVIRONMENT"
        delete_all "$ENVIRONMENT"
        ;;
    delete-stack)
        validate_environment "$ENVIRONMENT"
        if [[ -z "$STACK" ]]; then
            log_error "--stack parameter required"
            usage
        fi
        delete_stack "$STACK" "$ENVIRONMENT"
        ;;
    list)
        validate_environment "$ENVIRONMENT"
        list_stacks "$ENVIRONMENT"
        ;;
    status)
        validate_environment "$ENVIRONMENT"
        show_status "$ENVIRONMENT"
        ;;
    *)
        log_error "Unknown command: $COMMAND"
        usage
        ;;
esac
