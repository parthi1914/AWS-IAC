#!/bin/bash

# =============================================================================
# Enterprise IAC Pipeline - Deployment Script
# =============================================================================
# Usage: ./deploy.sh [command] [options]
# Commands: deploy-pipeline, deploy-stack, validate, status, delete
# =============================================================================

set -e

# Configuration
PROJECT_NAME="${PROJECT_NAME:-enterprise-iac}"
AWS_REGION="${AWS_REGION:-us-east-1}"
STACK_PREFIX="${PROJECT_NAME}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# =============================================================================
# Helper Functions
# =============================================================================

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

usage() {
    cat << EOF
Usage: $0 [command] [options]

Commands:
    deploy-pipeline     Deploy the CI/CD Pipeline stack
    deploy-stack        Deploy a specific stack (vpc, alb, ecs, etc.)
    validate            Validate all CloudFormation templates
    status              Show status of all stacks
    delete              Delete a specific stack
    init-repo           Initialize CodeCommit repository with templates

Options:
    -e, --environment   Environment (staging/production)
    -n, --name          Stack name suffix
    -p, --profile       AWS CLI profile
    -r, --region        AWS region
    -h, --help          Show this help message

Examples:
    $0 deploy-pipeline --profile dev-account
    $0 deploy-stack --environment staging --name vpc
    $0 validate
    $0 status
    $0 delete --name staging-vpc

EOF
    exit 1
}

# =============================================================================
# Validation Functions
# =============================================================================

validate_templates() {
    log_info "Validating CloudFormation templates..."
    
    local templates_dir="templates"
    local error_count=0
    
    for template in ${templates_dir}/*.yaml; do
        if [ -f "$template" ]; then
            log_info "Validating: $template"
            
            # YAML syntax check
            python3 -c "import yaml; yaml.safe_load(open('$template'))" 2>/dev/null || {
                log_error "YAML syntax error in $template"
                ((error_count++))
                continue
            }
            
            # AWS CloudFormation validate
            aws cloudformation validate-template \
                --template-body "file://$template" \
                --region "$AWS_REGION" \
                ${AWS_PROFILE:+--profile "$AWS_PROFILE"} \
                > /dev/null 2>&1 || {
                log_error "CloudFormation validation failed for $template"
                ((error_count++))
                continue
            }
            
            log_success "✓ $template is valid"
        fi
    done
    
    if [ $error_count -eq 0 ]; then
        log_success "All templates are valid!"
        return 0
    else
        log_error "$error_count template(s) failed validation"
        return 1
    fi
}

# =============================================================================
# Deployment Functions
# =============================================================================

deploy_pipeline() {
    log_info "Deploying CI/CD Pipeline Stack..."
    
    local stack_name="${STACK_PREFIX}-cicd-pipeline"
    local template="templates/01-cicd-pipeline-stack.yaml"
    
    # Check if stack exists
    if aws cloudformation describe-stacks \
        --stack-name "$stack_name" \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"} \
        > /dev/null 2>&1; then
        log_info "Stack exists, updating..."
        local action="update-stack"
    else
        log_info "Creating new stack..."
        local action="create-stack"
    fi
    
    # Get email for notifications
    if [ -z "$NOTIFICATION_EMAIL" ]; then
        read -p "Enter notification email: " NOTIFICATION_EMAIL
    fi
    
    # Deploy the stack
    aws cloudformation $action \
        --stack-name "$stack_name" \
        --template-body "file://$template" \
        --parameters \
            ParameterKey=ProjectName,ParameterValue="$PROJECT_NAME" \
            ParameterKey=NotificationEmail,ParameterValue="$NOTIFICATION_EMAIL" \
            ParameterKey=StagingVpcCidr,ParameterValue="${STAGING_VPC_CIDR:-10.1.0.0/16}" \
            ParameterKey=ProdVpcCidr,ParameterValue="${PROD_VPC_CIDR:-10.2.0.0/16}" \
        --capabilities CAPABILITY_NAMED_IAM \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"} \
        --tags Key=Project,Value="$PROJECT_NAME" Key=ManagedBy,Value=CloudFormation
    
    log_info "Waiting for stack operation to complete..."
    
    if [ "$action" == "create-stack" ]; then
        aws cloudformation wait stack-create-complete \
            --stack-name "$stack_name" \
            --region "$AWS_REGION" \
            ${AWS_PROFILE:+--profile "$AWS_PROFILE"}
    else
        aws cloudformation wait stack-update-complete \
            --stack-name "$stack_name" \
            --region "$AWS_REGION" \
            ${AWS_PROFILE:+--profile "$AWS_PROFILE"}
    fi
    
    log_success "Pipeline stack deployed successfully!"
    
    # Show outputs
    show_stack_outputs "$stack_name"
}

deploy_stack() {
    local environment="${1:-staging}"
    local stack_type="${2:-vpc}"
    local stack_name="${STACK_PREFIX}-${environment}-${stack_type}"
    local template="templates/02-vpc-stack.yaml"
    local params_file="parameters/${environment}-params.json"
    
    log_info "Deploying $stack_name..."
    
    if [ ! -f "$params_file" ]; then
        log_error "Parameter file not found: $params_file"
        return 1
    fi
    
    # Check if stack exists
    if aws cloudformation describe-stacks \
        --stack-name "$stack_name" \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"} \
        > /dev/null 2>&1; then
        log_info "Stack exists, updating..."
        local action="update-stack"
    else
        log_info "Creating new stack..."
        local action="create-stack"
    fi
    
    # Get AZ values
    local az1=$(aws ec2 describe-availability-zones \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"} \
        --query 'AvailabilityZones[0].ZoneName' \
        --output text)
    local az2=$(aws ec2 describe-availability-zones \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"} \
        --query 'AvailabilityZones[1].ZoneName' \
        --output text)
    
    aws cloudformation $action \
        --stack-name "$stack_name" \
        --template-body "file://$template" \
        --parameters file://"$params_file" \
            ParameterKey=AvailabilityZone1,ParameterValue="$az1" \
            ParameterKey=AvailabilityZone2,ParameterValue="$az2" \
        --capabilities CAPABILITY_NAMED_IAM \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"} \
        --tags Key=Project,Value="$PROJECT_NAME" Key=Environment,Value="$environment"
    
    log_info "Waiting for stack operation to complete..."
    
    if [ "$action" == "create-stack" ]; then
        aws cloudformation wait stack-create-complete \
            --stack-name "$stack_name" \
            --region "$AWS_REGION" \
            ${AWS_PROFILE:+--profile "$AWS_PROFILE"}
    else
        aws cloudformation wait stack-update-complete \
            --stack-name "$stack_name" \
            --region "$AWS_REGION" \
            ${AWS_PROFILE:+--profile "$AWS_PROFILE"}
    fi
    
    log_success "Stack $stack_name deployed successfully!"
    show_stack_outputs "$stack_name"
}

# =============================================================================
# Status and Management Functions
# =============================================================================

show_status() {
    log_info "Checking stack status..."
    
    echo ""
    echo "================================================================================"
    echo "Stack Status for Project: $PROJECT_NAME"
    echo "================================================================================"
    
    aws cloudformation list-stacks \
        --stack-status-filter CREATE_COMPLETE UPDATE_COMPLETE CREATE_IN_PROGRESS UPDATE_IN_PROGRESS \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"} \
        --query "StackSummaries[?contains(StackName, '${STACK_PREFIX}')].[StackName,StackStatus,CreationTime]" \
        --output table
    
    echo ""
}

show_stack_outputs() {
    local stack_name="$1"
    
    log_info "Stack Outputs for $stack_name:"
    echo ""
    
    aws cloudformation describe-stacks \
        --stack-name "$stack_name" \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"} \
        --query 'Stacks[0].Outputs[*].[OutputKey,OutputValue]' \
        --output table 2>/dev/null || {
        log_warning "Could not retrieve stack outputs"
    }
}

delete_stack() {
    local stack_name="${1}"
    
    if [ -z "$stack_name" ]; then
        log_error "Stack name required"
        return 1
    fi
    
    log_warning "You are about to delete stack: $stack_name"
    read -p "Are you sure? (yes/no): " confirm
    
    if [ "$confirm" != "yes" ]; then
        log_info "Deletion cancelled"
        return 0
    fi
    
    log_info "Deleting stack $stack_name..."
    
    aws cloudformation delete-stack \
        --stack-name "$stack_name" \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"}
    
    log_info "Waiting for stack deletion..."
    
    aws cloudformation wait stack-delete-complete \
        --stack-name "$stack_name" \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"}
    
    log_success "Stack $stack_name deleted successfully!"
}

init_repo() {
    log_info "Initializing CodeCommit repository..."
    
    # Get repository URL from stack outputs
    local repo_url=$(aws cloudformation describe-stacks \
        --stack-name "${STACK_PREFIX}-cicd-pipeline" \
        --region "$AWS_REGION" \
        ${AWS_PROFILE:+--profile "$AWS_PROFILE"} \
        --query 'Stacks[0].Outputs[?OutputKey==`CodeCommitRepositoryUrl`].OutputValue' \
        --output text 2>/dev/null)
    
    if [ -z "$repo_url" ]; then
        log_error "Could not retrieve CodeCommit repository URL. Deploy pipeline first."
        return 1
    fi
    
    log_info "Repository URL: $repo_url"
    
    # Initialize git and push
    git init
    git add .
    git commit -m "Initial commit: Enterprise IAC Pipeline templates"
    git remote add codecommit "$repo_url" 2>/dev/null || git remote set-url codecommit "$repo_url"
    
    log_info "Pushing to CodeCommit..."
    git push codecommit main --force
    
    log_success "Repository initialized and pushed!"
}

# =============================================================================
# Main Script
# =============================================================================

# Parse arguments
COMMAND=""
ENVIRONMENT=""
STACK_NAME=""

while [[ $# -gt 0 ]]; do
    case $1 in
        deploy-pipeline|deploy-stack|validate|status|delete|init-repo)
            COMMAND="$1"
            shift
            ;;
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -n|--name)
            STACK_NAME="$2"
            shift 2
            ;;
        -p|--profile)
            AWS_PROFILE="$2"
            shift 2
            ;;
        -r|--region)
            AWS_REGION="$2"
            shift 2
            ;;
        -h|--help)
            usage
            ;;
        *)
            log_error "Unknown option: $1"
            usage
            ;;
    esac
done

# Execute command
case $COMMAND in
    deploy-pipeline)
        validate_templates
        deploy_pipeline
        ;;
    deploy-stack)
        validate_templates
        deploy_stack "$ENVIRONMENT" "vpc"
        ;;
    validate)
        validate_templates
        ;;
    status)
        show_status
        ;;
    delete)
        delete_stack "${STACK_PREFIX}-${STACK_NAME}"
        ;;
    init-repo)
        init_repo
        ;;
    *)
        usage
        ;;
esac
