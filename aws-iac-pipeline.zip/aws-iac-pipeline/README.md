# Enterprise AWS IAC Pipeline

Enterprise-grade Infrastructure as Code (IaC) CI/CD Pipeline using AWS CloudFormation, CodePipeline, and CodeCommit.

## Architecture Overview

This solution implements the CI/CD IAC Pipeline pattern with:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         CI/CD IAC Pipeline Stack                            │
│  ┌─────────┐    ┌─────────┐    ┌─────┐    ┌─────┐    ┌──────────────────┐  │
│  │CodeCommit├───►│CodeBuild├───►│ S3  ├───►│ SNS │    │   CodePipeline   │  │
│  └─────────┘    └─────────┘    └─────┘    └─────┘    └──────────────────┘  │
│       │              │                                        │             │
│       │              │         ┌──────────────────────────────┴──────┐      │
│       │              │         │                                      │      │
│       ▼              ▼         ▼                                      ▼      │
│  ┌─────────┐   ┌──────────┐  ┌──────────────────┐    ┌──────────────────┐  │
│  │ Source  │   │  Build   │  │  Staging Deploy  │    │  Prod Deploy     │  │
│  │  Stage  │   │  Stage   │  │  (Direct Create) │    │  (Change Set +   │  │
│  └─────────┘   └──────────┘  └──────────────────┘    │   Approval)      │  │
│                                       │               └──────────────────┘  │
└───────────────────────────────────────┼──────────────────────┼──────────────┘
                                        │                      │
                                        ▼                      ▼
                               ┌────────────────┐    ┌────────────────┐
                               │  Staging VPC   │    │    Prod VPC    │
                               │     Stack      │    │     Stack      │
                               │  ┌──────────┐  │    │  ┌──────────┐  │
                               │  │   VPC    │  │    │  │   VPC    │  │
                               │  │ Subnets  │  │    │  │ Subnets  │  │
                               │  │Route Tbl │  │    │  │Route Tbl │  │
                               │  │   IGW    │  │    │  │   IGW    │  │
                               │  │   NAT    │  │    │  │ NAT (HA) │  │
                               │  └──────────┘  │    │  └──────────┘  │
                               └────────────────┘    └────────────────┘
```

## Features

- **Automated CI/CD Pipeline**: Push to CodeCommit triggers automatic deployments
- **Multi-Environment Support**: Staging (direct deploy) and Production (change set with approval)
- **Template Validation**: cfn-lint, checkov security scanning, AWS validation
- **Enterprise Security**: Least privilege IAM, VPC Flow Logs, encryption at rest
- **High Availability**: Multi-AZ NAT Gateways for production

## Project Structure

```
aws-iac-pipeline/
├── templates/
│   ├── 01-cicd-pipeline-stack.yaml    # Main CI/CD Pipeline
│   └── 02-vpc-stack.yaml              # VPC Network Stack
├── parameters/
│   ├── staging-params.json            # Staging environment config
│   └── prod-params.json               # Production environment config
├── buildspecs/
│   └── validate-buildspec.yaml        # CodeBuild validation spec
├── scripts/
│   └── deploy.sh                      # Deployment automation script
└── README.md
```

## Quick Start

### Prerequisites

- AWS CLI configured with appropriate credentials
- Python 3.8+ (for cfn-lint)
- Git

### Step 1: Deploy the Pipeline

```bash
# Set environment variables
export PROJECT_NAME=enterprise-iac
export AWS_REGION=us-east-1
export NOTIFICATION_EMAIL=your-email@company.com

# Deploy the CI/CD Pipeline stack
./scripts/deploy.sh deploy-pipeline
```

### Step 2: Initialize CodeCommit Repository

```bash
# Push templates to CodeCommit (triggers the pipeline)
./scripts/deploy.sh init-repo
```

### Step 3: Monitor Pipeline

The pipeline will automatically:
1. **Source Stage**: Pull code from CodeCommit
2. **Build Stage**: Validate templates (cfn-lint, checkov, AWS validate)
3. **Staging Stage**: Deploy VPC directly to staging
4. **Production Stage**: 
   - Create change set
   - Wait for manual approval (SNS notification sent)
   - Execute change set after approval

## Template Details

### CI/CD Pipeline Stack (01-cicd-pipeline-stack.yaml)

Creates the foundational CI/CD infrastructure:

| Resource | Description |
|----------|-------------|
| CodeCommit Repository | Source code repository |
| CodeBuild Project | Template validation |
| CodePipeline | Orchestrates the deployment flow |
| S3 Buckets | Artifacts and templates storage |
| SNS Topic | Pipeline notifications |
| IAM Roles | Service roles with least privilege |
| EventBridge Rule | Triggers pipeline on git push |

### VPC Stack (02-vpc-stack.yaml)

Creates enterprise network infrastructure:

| Resource | Description |
|----------|-------------|
| VPC | Isolated virtual network |
| Public Subnets (2) | For ALB, NAT Gateways |
| Private Subnets (2) | For ECS tasks, databases |
| Internet Gateway | Public internet access |
| NAT Gateways | Outbound for private subnets |
| Route Tables | Traffic routing |
| Security Groups | ALB, App, Database tiers |
| VPC Flow Logs | Network monitoring |
| S3 VPC Endpoint | Private S3 access |

## Configuration

### Staging Parameters (staging-params.json)

```json
{
  "Parameters": {
    "Environment": "staging",
    "VpcCidr": "10.1.0.0/16",
    "NatGatewayStrategy": "SingleAZ"
  }
}
```

### Production Parameters (prod-params.json)

```json
{
  "Parameters": {
    "Environment": "production",
    "VpcCidr": "10.2.0.0/16",
    "NatGatewayStrategy": "MultiAZ"
  }
}
```

## Deployment Workflow

### For Staging (Direct Deploy)
```
Git Push → CodePipeline → Validate → CloudFormation CreateStack/UpdateStack
```

### For Production (Change Set with Approval)
```
Git Push → CodePipeline → Validate → Create ChangeSet → Manual Approval → Execute ChangeSet
```

## CLI Commands

```bash
# Validate all templates
./scripts/deploy.sh validate

# Deploy pipeline infrastructure
./scripts/deploy.sh deploy-pipeline

# Deploy specific stack manually
./scripts/deploy.sh deploy-stack --environment staging

# Check status of all stacks
./scripts/deploy.sh status

# Delete a stack
./scripts/deploy.sh delete --name staging-vpc
```

## Security Features

- **Encryption**: All S3 buckets encrypted with AES-256
- **Access Control**: Least privilege IAM policies
- **Network Security**: Private subnets for workloads
- **Monitoring**: VPC Flow Logs enabled
- **Audit**: CloudTrail integration ready

## Extending the Pipeline

### Adding New Stacks

1. Create template in `templates/` directory
2. Add parameter files in `parameters/`
3. Update pipeline template to include new stages
4. Push to CodeCommit

### Adding New Environments

1. Create parameter file: `parameters/{env}-params.json`
2. Add new stage in pipeline template
3. Update IAM policies if needed

## Troubleshooting

### Pipeline Fails at Validation

Check CodeBuild logs:
```bash
aws logs get-log-events \
  --log-group-name /aws/codebuild/enterprise-iac-validate \
  --log-stream-name <stream-name>
```

### Stack Creation Fails

Check CloudFormation events:
```bash
aws cloudformation describe-stack-events \
  --stack-name enterprise-iac-staging-vpc
```

### Common Issues

| Issue | Solution |
|-------|----------|
| IAM permissions | Check CloudFormation service role |
| Template syntax | Run `cfn-lint templates/*.yaml` |
| Parameter mismatch | Verify parameter files match template |

## Cost Considerations

| Resource | Staging Cost | Production Cost |
|----------|--------------|-----------------|
| NAT Gateway | ~$32/month (1x) | ~$64/month (2x) |
| VPC Flow Logs | ~$0.50/GB | ~$0.50/GB |
| CodePipeline | ~$1/pipeline | ~$1/pipeline |
| CodeBuild | Pay per build | Pay per build |

## License

MIT License - See LICENSE file for details.

## Support

For issues and feature requests, please open an issue in the repository.
