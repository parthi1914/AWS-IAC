import os
import json

def handler(event, context):
    return {
        "statusCode": 200,
        "headers": {"content-type": "application/json"},
        "body": json.dumps({
            "message": "hq enterprise lambda behind alb is working",
            "env": os.getenv("APP_ENV"),
            "bucket": os.getenv("APP_BUCKET"),
            "secretArn": os.getenv("SECRET_ARN")
        })
    }
