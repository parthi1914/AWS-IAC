# GE Aerospace - Enterprise AWS Infra (CloudFormation + CodePipeline multi-stage)

This repo deploys an **enterprise baseline** aligned to the naming convention:
`hq-<Workstream>-<AppName>-<Env>-<ResourceType>-<Purpose>` (+ region code where practical)

## What gets created (per environment)
- ALB (HTTP + optional HTTPS) with **access logs** to S3 (SSE-KMS)
- **WAFv2** WebACL (AWS managed rules) associated to ALB
- S3 App bucket (SSE-KMS, versioning, block public access)
- Secrets Manager secret encrypted with **KMS CMK**
- Lambda (behind ALB via Lambda Target Group)
- CloudWatch alarms (ALB 5XX + Lambda Errors/Throttles) -> SNS topic

## Files
- `pipeline/codepipeline-multistage.yml` : Creates one CodePipeline with stages **dev → qa → uat → prod** with **manual approvals**
- `infra/templates/root.yml` : Root stack (nested stacks)
- `infra/templates/nested/*` : Nested stacks (kms, s3, waf, alb, lambda, alarms)

## Prerequisites
1) A GitHub repo containing this content.
2) CodeStar Connection to GitHub (Console: Developer Tools → Settings → Connections).
3) Existing VPC + public subnets for each environment.
4) Optional: ACM certificate ARN for **prod** (and any env where you enable HTTPS).

## How to deploy
### Option A (recommended): Create the pipeline stack
1) Open CloudFormation and create a stack using:
   `pipeline/codepipeline-multistage.yml`
2) Provide parameters:
   - Workstream, AppName, RegionCode
   - CodeStarConnectionArn, RepoOwner/RepoName/RepoBranch
   - VPC/Subnet ids for each env (dev/qa/uat/prod)
   - CertificateArnProd (optional if EnableHttpsProd=true)

The pipeline will:
- Build: zip Lambda + upload to artifact bucket under `lambda/<env>/app.zip`
- Sync templates to artifact bucket under `templates/`
- Deploy stacks per env with manual approvals between stages

### Option B: Deploy only one environment (no pipeline)
1) Upload the `infra/templates` folder to an S3 bucket and set `ArtifactBucketName`.
2) Create stack using `infra/templates/root.yml` with parameters for a single env.

## Notes / Limits
- Target group names have a **32 character** limit; this repo uses `hq-<ws>-<app>-<env>-tg`.
- S3 bucket names are globally unique and include AccountId + Region.
- All names are lowercase and avoid special characters.

