#!/bin/bash
# =============================================================================
# GE Aerospace CloudFormation Deployment Script
# Naming Convention: hq-<Workstream>-<AppName>-<Env>-cf-<stack>
# =============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Default values
WORKSTREAM="edm"
APP_NAME="idmc"
ENVIRONMENT="dev"
REGION="us-east-1"
ACTION="deploy"

# Usage
usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -w, --workstream    Workstream identifier (default: edm)"
    echo "  -a, --appname       Application name (default: idmc)"
    echo "  -e, --environment   Environment: dev|qa|staging|prod (default: dev)"
    echo "  -r, --region        AWS Region (default: us-east-1)"
    echo "  -s, --stack         Stack to deploy: alb|s3|lambda|secrets|ecs|all"
    echo "  -d, --delete        Delete stack instead of deploy"
    echo "  -h, --help          Show this help"
    echo ""
    echo "Examples:"
    echo "  $0 -e dev -s alb                    # Deploy ALB to dev"
    echo "  $0 -e prod -s all                   # Deploy all stacks to prod"
    echo "  $0 -e dev -s ecs -d                 # Delete ECS stack from dev"
    exit 1
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -w|--workstream) WORKSTREAM="$2"; shift 2 ;;
        -a|--appname) APP_NAME="$2"; shift 2 ;;
        -e|--environment) ENVIRONMENT="$2"; shift 2 ;;
        -r|--region) REGION="$2"; shift 2 ;;
        -s|--stack) STACK="$2"; shift 2 ;;
        -d|--delete) ACTION="delete"; shift ;;
        -h|--help) usage ;;
        *) echo "Unknown option: $1"; usage ;;
    esac
done

# Validate environment
if [[ ! "$ENVIRONMENT" =~ ^(dev|qa|staging|prod)$ ]]; then
    echo -e "${RED}Error: Invalid environment. Must be dev|qa|staging|prod${NC}"
    exit 1
fi

# Load parameters
PARAMS_FILE="parameters/${ENVIRONMENT}-params.json"
if [[ ! -f "$PARAMS_FILE" ]]; then
    echo -e "${YELLOW}Warning: ${PARAMS_FILE} not found, using defaults${NC}"
fi

# Stack naming function
get_stack_name() {
    local stack_type=$1
    echo "hq-${WORKSTREAM}-${APP_NAME}-${ENVIRONMENT}-cf-${stack_type}"
}

# Deploy function
deploy_stack() {
    local stack_type=$1
    local template_file=$2
    local stack_name=$(get_stack_name "$stack_type")
    
    echo -e "${GREEN}Deploying: ${stack_name}${NC}"
    
    # Check if stack exists
    if aws cloudformation describe-stacks --stack-name "$stack_name" --region "$REGION" &>/dev/null; then
        echo -e "${YELLOW}Stack exists, updating...${NC}"
        OPERATION="update-stack"
    else
        echo -e "${GREEN}Creating new stack...${NC}"
        OPERATION="create-stack"
    fi
    
    # Build parameters from JSON file
    PARAMS=""
    if [[ -f "$PARAMS_FILE" ]]; then
        PARAMS=$(jq -r '.Parameters | to_entries | map("ParameterKey=\(.key),ParameterValue=\(.value)") | join(" ")' "$PARAMS_FILE")
    fi
    
    # Add required naming parameters
    PARAMS="$PARAMS ParameterKey=Workstream,ParameterValue=${WORKSTREAM}"
    PARAMS="$PARAMS ParameterKey=AppName,ParameterValue=${APP_NAME}"
    PARAMS="$PARAMS ParameterKey=Environment,ParameterValue=${ENVIRONMENT}"
    
    # Build tags
    TAGS="Key=app,Value=hq-${WORKSTREAM}-${APP_NAME}"
    TAGS="$TAGS Key=Environment,Value=${ENVIRONMENT}"
    TAGS="$TAGS Key=ManagedBy,Value=CloudFormation"
    
    # Deploy
    if [[ "$template_file" == *"lambda"* ]]; then
        # Lambda requires SAM transform
        aws cloudformation deploy \
            --stack-name "$stack_name" \
            --template-file "templates/${template_file}" \
            --parameter-overrides $PARAMS \
            --capabilities CAPABILITY_NAMED_IAM CAPABILITY_AUTO_EXPAND \
            --tags $TAGS \
            --region "$REGION" \
            --no-fail-on-empty-changeset
    else
        aws cloudformation deploy \
            --stack-name "$stack_name" \
            --template-file "templates/${template_file}" \
            --parameter-overrides $PARAMS \
            --capabilities CAPABILITY_NAMED_IAM \
            --tags $TAGS \
            --region "$REGION" \
            --no-fail-on-empty-changeset
    fi
    
    echo -e "${GREEN}✓ Stack deployed: ${stack_name}${NC}"
}

# Delete function
delete_stack() {
    local stack_type=$1
    local stack_name=$(get_stack_name "$stack_type")
    
    echo -e "${YELLOW}Deleting: ${stack_name}${NC}"
    
    aws cloudformation delete-stack \
        --stack-name "$stack_name" \
        --region "$REGION"
    
    echo "Waiting for stack deletion..."
    aws cloudformation wait stack-delete-complete \
        --stack-name "$stack_name" \
        --region "$REGION"
    
    echo -e "${GREEN}✓ Stack deleted: ${stack_name}${NC}"
}

# Validate templates
validate_templates() {
    echo -e "${GREEN}Validating templates...${NC}"
    for template in templates/*.yaml; do
        echo "Validating: $template"
        aws cloudformation validate-template \
            --template-body "file://${template}" \
            --region "$REGION" > /dev/null
    done
    echo -e "${GREEN}✓ All templates valid${NC}"
}

# Main execution
echo "============================================="
echo "GE Aerospace CFT Deployment"
echo "============================================="
echo "Workstream:  ${WORKSTREAM}"
echo "App Name:    ${APP_NAME}"
echo "Environment: ${ENVIRONMENT}"
echo "Region:      ${REGION}"
echo "Action:      ${ACTION}"
echo "Stack:       ${STACK:-all}"
echo "============================================="

# Validate first
validate_templates

# Execute based on action and stack
if [[ "$ACTION" == "delete" ]]; then
    case $STACK in
        alb) delete_stack "alb" ;;
        s3) delete_stack "s3" ;;
        lambda) delete_stack "lambda" ;;
        secrets) delete_stack "secrets" ;;
        ecs) delete_stack "ecs" ;;
        all)
            delete_stack "ecs"
            delete_stack "lambda"
            delete_stack "secrets"
            delete_stack "alb"
            delete_stack "s3"
            ;;
        *) echo "Invalid stack: $STACK"; usage ;;
    esac
else
    case $STACK in
        alb) deploy_stack "alb" "01-alb-stack.yaml" ;;
        s3) deploy_stack "s3" "02-s3-stack.yaml" ;;
        lambda) deploy_stack "lambda" "03-lambda-stack.yaml" ;;
        secrets) deploy_stack "secrets" "04-secrets-manager-stack.yaml" ;;
        ecs) deploy_stack "ecs" "05-ecs-stack.yaml" ;;
        all)
            deploy_stack "s3" "02-s3-stack.yaml"
            deploy_stack "secrets" "04-secrets-manager-stack.yaml"
            deploy_stack "alb" "01-alb-stack.yaml"
            deploy_stack "lambda" "03-lambda-stack.yaml"
            deploy_stack "ecs" "05-ecs-stack.yaml"
            ;;
        *) echo "Invalid stack: $STACK"; usage ;;
    esac
fi

echo ""
echo -e "${GREEN}============================================="
echo "Deployment Complete!"
echo "=============================================${NC}"
