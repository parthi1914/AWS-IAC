# GE Aerospace CloudFormation Templates

Enterprise-level CloudFormation templates following GE Aerospace naming standards.

## Naming Convention

```
Pattern: hq-<Workstream>-<AppName>-<Env>-<ResourceType>-<Purpose>
```

### Constraints
- **Max Length**: 63 characters (S3, RDS, Lambda)
- **Target Groups**: 32 characters max
- **Case**: Lowercase (except AppCID in tags)
- **Characters**: Alphanumeric and hyphens only

### Resource Examples

| Resource | Pattern | Example |
|----------|---------|---------|
| ALB | `hq-<ws>-<app>-<env>-alb` | `hq-edm-idmc-dev-alb` |
| Target Group | `hq-<ws>-<app>-<env>-tg` | `hq-edm-idmc-dev-tg` |
| S3 Bucket | `hq-<ws>-<app>-<env>-s3-<purpose>` | `hq-edm-idmc-dev-s3-staging` |
| Lambda | `hq-<ws>-<app>-<env>-lambda-<purpose>` | `hq-edm-idmc-dev-lambda-html` |
| ECS Cluster | `hq-<ws>-<app>-<env>-ecs-cluster` | `hq-edm-idmc-dev-ecs-cluster` |
| ECS Service | `hq-<ws>-<app>-<env>-ecs-service` | `hq-edm-idmc-dev-ecs-service` |
| IAM Role | `hq-<ws>-servicerole-<type>` | `hq-edm-servicerole-ecs-task` |
| Secrets | `hq/<ws>/<env>/<app>/<purpose>` | `hq/edm/dev/idmc/dbcreds` |
| CF Stack | `hq-<ws>-<app>-<env>-cf-<stack>` | `hq-edm-idmc-dev-cf-alb` |

---

## Project Structure

```
ge-aerospace-cft/
├── templates/
│   ├── 01-alb-stack.yaml          # Application Load Balancer
│   ├── 02-s3-stack.yaml           # S3 Bucket
│   ├── 03-lambda-stack.yaml       # Lambda Function
│   ├── 04-secrets-manager-stack.yaml  # Secrets Manager
│   └── 05-ecs-stack.yaml          # ECS Fargate
├── parameters/
│   ├── dev-params.json            # Dev environment parameters
│   └── prod-params.json           # Prod environment parameters
├── scripts/
│   └── deploy.sh                  # Deployment script
├── buildspecs/
│   └── validate-buildspec.yaml    # CodePipeline validation
├── .gitignore
└── README.md
```

---

## Templates

### 01-alb-stack.yaml
Application Load Balancer with HTTP/HTTPS listeners.

**Key Parameters:**
- `Workstream`, `AppName`, `Environment` - Naming
- `VpcId`, `SubnetIds`, `SecurityGroupIds` - Network
- `Scheme` - internal/internet-facing
- `EnableHTTPS`, `CertificateArn` - HTTPS config

### 02-s3-stack.yaml
S3 bucket with versioning, encryption, and security.

**Key Parameters:**
- `Purpose` - staging, artifacts, logs, etc.
- `EnableVersioning` - true/false
- `EncryptionType` - AES256 or aws:kms

### 03-lambda-stack.yaml
Lambda function with IAM role and CloudWatch logs.

**Key Parameters:**
- `Purpose` - html, api, processor, etc.
- `Runtime` - nodejs22.x, python3.12, etc.
- `S3Bucket`, `S3Key` - Code location
- Environment variables for integration

### 04-secrets-manager-stack.yaml
Secrets with auto-generation and SSM reference.

**Key Parameters:**
- `Purpose` - dbcreds, apikey, oauth
- `NamingStyle` - hyphenated or hierarchical
- `SecretType` - database, api-key, oauth, generic

### 05-ecs-stack.yaml
ECS Fargate cluster, service, and auto-scaling.

**Key Parameters:**
- `ContainerImage` - Docker image URI
- `ContainerPort` - Application port (default: 3000)
- `TaskCpu`, `TaskMemory` - Task resources
- `DesiredCount`, `MinCapacity`, `MaxCapacity` - Scaling
- `TargetGroupArn` - ALB integration

---

## Deployment

### Prerequisites
1. AWS CLI configured
2. Required IAM permissions
3. jq installed (for deploy script)

### Using Deploy Script

```bash
# Make script executable
chmod +x scripts/deploy.sh

# Deploy single stack
./scripts/deploy.sh -e dev -s alb

# Deploy all stacks
./scripts/deploy.sh -e dev -s all

# Deploy to production
./scripts/deploy.sh -e prod -s all

# Delete stack
./scripts/deploy.sh -e dev -s ecs -d
```

### Manual Deployment

```bash
# Deploy ALB
aws cloudformation deploy \
  --stack-name hq-edm-idmc-dev-cf-alb \
  --template-file templates/01-alb-stack.yaml \
  --parameter-overrides \
    Workstream=edm \
    AppName=idmc \
    Environment=dev \
    VpcId=vpc-xxxxx \
    SubnetIds=subnet-xxx,subnet-xxx \
    SecurityGroupIds=sg-xxx \
    AppCID=AVEDM \
    CostCenter=12345 \
    Owner=edm-team@ge.com \
  --capabilities CAPABILITY_NAMED_IAM \
  --tags app=hq-edm-idmc Environment=dev

# Deploy ECS (requires ALB first)
aws cloudformation deploy \
  --stack-name hq-edm-idmc-dev-cf-ecs \
  --template-file templates/05-ecs-stack.yaml \
  --parameter-overrides \
    Workstream=edm \
    AppName=idmc \
    Environment=dev \
    VpcId=vpc-xxxxx \
    PrivateSubnetIds=subnet-xxx,subnet-xxx \
    SecurityGroupId=sg-xxx \
    TargetGroupArn=arn:aws:elasticloadbalancing:... \
    AppCID=AVEDM \
    CostCenter=12345 \
    Owner=edm-team@ge.com \
  --capabilities CAPABILITY_NAMED_IAM
```

---

## Required Tags (GE Aerospace)

All resources include:
- `Name` - Resource name following convention
- `app` - `hq-<workstream>-<appname>`
- `AppCID` - Application CID
- `Environment` - dev/qa/staging/prod
- `CostCenter` - Cost center
- `Owner` - Owner email/team
- `ManagedBy` - CloudFormation

---

## Cross-Stack References

```yaml
# Import ALB outputs
!ImportValue hq-edm-idmc-dev-cf-alb-ALBArn
!ImportValue hq-edm-idmc-dev-cf-alb-TargetGroupArn

# Import S3 outputs
!ImportValue hq-edm-idmc-dev-cf-s3-BucketName
!ImportValue hq-edm-idmc-dev-cf-s3-BucketArn

# Import ECS outputs
!ImportValue hq-edm-idmc-dev-cf-ecs-ClusterArn
!ImportValue hq-edm-idmc-dev-cf-ecs-ServiceArn
```

---

## Git Workflow

```bash
# Clone and setup
git clone <repo-url>
cd ge-aerospace-cft

# Create feature branch
git checkout -b feature/add-new-template

# Make changes and commit
git add .
git commit -m "feat: add new template following naming convention"

# Push and create PR
git push origin feature/add-new-template
```

---

## Validation

```bash
# Validate all templates
for template in templates/*.yaml; do
  aws cloudformation validate-template --template-body "file://${template}"
done

# Lint with cfn-lint
pip install cfn-lint
cfn-lint templates/*.yaml
```

---

## Support

- **Naming Standards**: Confluence - RFVJY/Naming+Standards
- **Team**: edm-team@ge.com
